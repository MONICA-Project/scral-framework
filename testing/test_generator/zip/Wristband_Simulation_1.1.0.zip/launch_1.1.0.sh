java -jar wristband_simulation_1.1.0.jar settingsApplication_1.1.0.conf
